#视频录制大纲

一、算力服务器与数据库服务器申请与部署

1. 部署llm并在线提供AI对话服务
 1. ollama介绍
 2. 申请腾讯云算力HAI服务器部署ollama，并选择模型
 3. 开通ollama端口并对外api提供服务
 

2. 申请 TDSQL-C Serverless 服务进行并导入商业数据
 1. 申请腾讯云 TDSQL-C Serverless 服务，并开通对外连接
 2. 使用 TDSQL-C Serverless 导入电商数据
 
二、 电商商城数据结构设计与分析 

1. 电商商业数据结构关联分析
2. 电商商业数据的查询操作

三、 设计自然语言对话AI查询的操作流程

1. 从自然语言到plotly图表生成的流程图设计

四、 基于langchang实现text2sql服务

1. 连接 llama3.1 大模型
2. 构建SQL-chain向大语言模型中导入数据库schema
3. 构建User-chain向模型中传递用户提问数据，并生成sql查询

五、 结合 TDSQL-C Serverless 实现电商数据查询操作并构建plotly图表

1. 连接SQL并执行SQL操作，获取查询结果
2. 基于大语言模型生成plotly图表代码并执行
3. 生成plotly图表并在web中展示


六、 自然语言查询的UI构建

1. 基于streamlit构建llm对话UI
2. 调整代码打通UI与程序的连接